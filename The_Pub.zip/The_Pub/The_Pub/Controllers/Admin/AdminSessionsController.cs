﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using The_Pub.Models;

namespace The_Pub.Controllers.Api
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminSessionsController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public AdminSessionsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: api/AdminSessions
        [HttpGet]
        public async Task<ActionResult<IEnumerable<AdminSession>>> GetAdminSessions()
        {
            return await _context.AdminSessions.ToListAsync();
        }

        // GET: api/AdminSessions/5
        [HttpGet("{id}")]
        public async Task<ActionResult<AdminSession>> GetAdminSession(int id)
        {
            var asession = await _context.AdminSessions.FindAsync(id);

            if (asession == null)
            {
                return NotFound();
            }

            return asession;
        }

        // DELETE: api/AdminSessions/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<AdminSession>> DeleteAdminSession(int id)
        {
            var adminSession = await _context.AdminSessions.FindAsync(id);
            if (adminSession == null)
            {
                return NotFound();
            }

            _context.AdminSessions.Remove(adminSession);
            await _context.SaveChangesAsync();

            return adminSession;
        }

        private bool AdminSessionExists(int id)
        {
            return _context.AdminSessions.Any(e => e.AdminSessionID == id);
        }
    }
}
