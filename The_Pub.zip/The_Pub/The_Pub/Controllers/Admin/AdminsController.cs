﻿using System;
using System.Linq;
using System.Security.Cryptography;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Scrypt;
using The_Pub.Models;

namespace The_Pub.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminsController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public AdminsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // POST: api/Admins
        [HttpPost]
        public async Task<ActionResult<Admin>> PostAdmin(Admin admin)
        {
            var adm = _context.Admins.Where(a => a.Username.Equals(admin.Username)).FirstOrDefault();
            var ases = new AdminSession();

            if (adm != null)
            {
                ScryptEncoder encoder = new ScryptEncoder();
                bool areEquals = encoder.Compare(admin.Password, adm.Password);

                if (areEquals == true)
                {
                    var str = new RNGCryptoServiceProvider();
                    byte[] rn = new byte[256];
                    str.GetBytes(rn);
                    var sid = Convert.ToBase64String(rn);

                    var ses = _context.AdminSessions.Where(a => a.AdminID.Equals(adm.AdminID)).FirstOrDefault();
                    if (ses == null)
                    {
                        ases.AdminID = adm.AdminID;
                        ases.Username = adm.Username;
                        ases.SessionID = sid;
                        ases.SessionTime = DateTime.Now;
                        _context.AdminSessions.Add(ases);
                    }                   
                    await _context.SaveChangesAsync();
                    return Ok("Login sucessful.");
                }
                else
                {
                    return BadRequest("Login failed.");
                }
            }
            else
            {
                return BadRequest("Login failed.");
            }
        }
        
        private bool AdminExists(int id)
        {
            return _context.Admins.Any(e => e.AdminID == id);
        }
    }
}
