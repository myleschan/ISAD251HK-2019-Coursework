﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using The_Pub.Models;

namespace The_Pub.Controllers.Api
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerSessionsController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public CustomerSessionsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: api/CustomerSessions
        [HttpGet]
        public async Task<ActionResult<IEnumerable<CustomerSession>>> GetCustomerSessions()
        {
            return await _context.CustomerSessions.ToListAsync();
        }

        // GET: api/CustomerSessions/5
        [HttpGet("{id}")]
        public async Task<ActionResult<CustomerSession>> GetCustomerSession(int id)
        {
            var csession = await _context.CustomerSessions.FindAsync(id);

            if (csession == null)
            {
                return NotFound();
            }

            return csession;
        }

        // DELETE: api/CustomerSessions/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<CustomerSession>> DeleteCustomerSession(int id)
        {
            var customerSession = await _context.CustomerSessions.FindAsync(id);
            if (customerSession == null)
            {
                return NotFound();
            }

            _context.CustomerSessions.Remove(customerSession);
            await _context.SaveChangesAsync();

            return customerSession;
        }

        private bool CustomerSessionExists(int id)
        {
            return _context.CustomerSessions.Any(e => e.CustomerSessionID == id);
        }
    }
}
