﻿using Microsoft.AspNetCore.Mvc;

namespace The_Pub.Controllers
{
    public class AdminController : Controller
    {
        public IActionResult Login()
        {
            return View();
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult ProductsView()
        {
            return View();
        }

        public IActionResult Create()
        {
            return View();
        }

        public IActionResult Edit()
        {
            return View();
        }

        public IActionResult Details()
        {
            return View();
        }

        public IActionResult UserOrderDetails()
        {
            return View();
        }

        public IActionResult SignOut()
        {
            return View("Home/Index");
        }
    }
}
