﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace The_Pub.Models
{
    public class CustomerSession
    {
        [Key]
        public int CustomerSessionID { get; set; }

        [Required]
        [ForeignKey("Customer")]
        public int CustomerID { get; set; }

        [Required]
        [ForeignKey("Customer")]
        [StringLength(50)]
        public string Username { get; set; }

        [Required]
        public string SessionID { get; set; }

        [Required]
        public DateTime SessionTime { get; set; }
    }
}
