using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace The_Pub.Models
{
    public class CartItem
    {
        [Key]
        public int CartItemID { get; set; }

        [Required]
        [StringLength(50)]
        public string Product { get; set; }

        [Required]
        [ForeignKey("Product")]
        public int Quantity { get; set; }

        [Required]
        [ForeignKey("Product")]
        [Column(TypeName = "decimal(18,2)")]
        public decimal Price { get; set; }

        [Required]
        [ForeignKey("Customer")]
        public string Username { get; set; }
    }
}
