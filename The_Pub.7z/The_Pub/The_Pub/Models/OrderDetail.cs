﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace The_Pub.Models
{
    public class OrderDetail
    {
        [Key]
        public int OrderID { get; set; }

        [Required]
        public DateTime OrderTime { get; set; }

        [Required]
        public int TableID { get; set; }

        [Required]
        public int CustomerID { get; set; }

        [Required]
        [StringLength(255)]
        public string Product { get; set; }

        [Required]
        public int Quantity { get; set; }

        [Required]
        [Column(TypeName = "decimal(18,2)")]
        public decimal Price { get; set; }
    }
}
