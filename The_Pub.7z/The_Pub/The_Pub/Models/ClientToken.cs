﻿using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;

namespace The_Pub.Models
{
    public class ClientToken
    {
        [Required]
        [JsonProperty("username")]
        public string Username { get; set; }


        [Required]
        [JsonProperty("password")]
        public string Password { get; set; }
    }
}
