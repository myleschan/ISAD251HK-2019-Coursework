﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace The_Pub.Models
{
    public class AdminSession
    {
        [Key]
        public int AdminSessionID { get; set; }

        [ForeignKey("Admin")]
        public int AdminID { get; set; }

        [Required]
        public string SessionID { get; set; }

        [Required]
        public DateTime SessionTime { get; set; }
    }
}
