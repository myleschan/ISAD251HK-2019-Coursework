﻿using System;
using System.Linq;
using System.Security.Cryptography;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Scrypt;
using The_Pub.Models;

namespace The_Pub.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomersController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public CustomersController(ApplicationDbContext context)
        {
            _context = context;
        }

        // POST: api/Customers
        [HttpPost]
        public async Task<ActionResult<Admin>> PostCustomer(Customer customer)
        {
            var cus = _context.Customers.Where(a => a.Username.Equals(customer.Username)).FirstOrDefault();
            var cses = new CustomerSession();

            if (cus != null)
            {
                ScryptEncoder encoder = new ScryptEncoder();
                bool areEquals = encoder.Compare(customer.Password, cus.Password);

                if (areEquals == true)
                {
                    var str = new RNGCryptoServiceProvider();
                    byte[] rn = new byte[256];
                    str.GetBytes(rn);
                    var sid = Convert.ToBase64String(rn);

                    cses.CustomerID = cus.CustomerID;
                    cses.SessionID = sid;
                    cses.SessionTime = DateTime.Now;
                    _context.CustomerSessions.Add(cses);
                    await _context.SaveChangesAsync();
                    return Ok("Login sucessful.");
                }
                else
                {
                    return BadRequest("Login failed.");
                }
            }
            else
            {
                return BadRequest("Login failed.");
            }
        }

        private bool CustomerExists(int id)
        {
            return _context.Customers.Any(e => e.CustomerID == id);
        }
    }
}
