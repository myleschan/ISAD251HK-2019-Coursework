﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using The_Pub.Models;

namespace The_Pub.Controllers.Api
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerSessionsController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public CustomerSessionsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: api/CustomerSessions
        [HttpGet]
        public async Task<ActionResult<IEnumerable<CustomerSession>>> GetCustomerSessions()
        {
            return await _context.CustomerSessions.ToListAsync();
        }

        // GET: api/CustomerSessions/5
        [HttpGet("{id}")]
        public async Task<ActionResult<CustomerSession>> GetCustomerSession(int id)
        {
            var csession = await _context.CustomerSessions.FindAsync(id);

            if (csession == null)
            {
                return NotFound();
            }

            return csession;
        }

        // DELETE: api/CustomerSessions/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<CustomerSession>> DeleteCustomerSession(int id)
        {
            var csession = await _context.CustomerSessions.FindAsync(id);
            if (csession == null)
            {
                return NotFound();
            }
            else
            {
                var cses = _context.CustomerSessions.SingleOrDefault(a => a.CustomerSessionID == HttpContext.Session.GetInt32("cid"));
                if ( cses != null)
                {
                    _context.CustomerSessions.Remove(csession);
                    await _context.SaveChangesAsync();
                }
            }
            return csession;
        }

        private bool CustomerSessionExists(int id)
        {
            return _context.CustomerSessions.Any(e => e.CustomerSessionID == id);
        }
    }
}
