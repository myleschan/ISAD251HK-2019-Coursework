﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using The_Pub.Models;
using The_Pub.Services;

namespace The_Pub.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthenticateController : ControllerBase
    {
        private readonly IAuthenticateService _authService;
        public AuthenticateController(IAuthenticateService authService)
        {
            _authService = authService;
        }

        [AllowAnonymous]
        [HttpPost, Route("request")]
        public IActionResult RequestToken([FromBody] ClientToken clientToken)
        {

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (_authService.IsAuthenticated(clientToken, out string token))
            {
                return Ok(token);
            }

            return BadRequest("Invalid Request");
        }
    }
}
