﻿using Microsoft.AspNetCore.Mvc;

namespace The_Pub.Controllers
{
    public class CustomerController : Controller
    {
        public IActionResult Login()
        {
            return View();
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Products()
        {
            return View();
        }

        public IActionResult ShoppingCart()
        {
            return View();
        }

        public IActionResult CheckOrderDetails()
        {
            return View();
        }

        public IActionResult SignOut()
        {
            return View("Home/Index");
        }
    }
}
