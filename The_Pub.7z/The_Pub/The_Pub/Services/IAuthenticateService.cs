﻿using The_Pub.Models;

namespace The_Pub.Services
{
    public interface IAuthenticateService
    {
        bool IsAuthenticated(ClientToken clientToken, out string token);
    }
}
