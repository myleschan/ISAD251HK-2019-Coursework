﻿namespace The_Pub.Services
{
    public interface IUserManagementService
    {
        bool IsValidUser(string username, string password);
    }
}
