﻿using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using The_Pub.Models;

namespace The_Pub.Services
{
    public class AuthenticationService : IAuthenticateService
    {
        private readonly IUserManagementService _userManagementService;
        private readonly Token _token;

        public AuthenticationService(IUserManagementService service, IOptions<Token> token)
        {
            _userManagementService = service;
            _token = token.Value;
        }
        public bool IsAuthenticated(ClientToken clientToken, out string token)
        {

            token = string.Empty;
            if (!_userManagementService.IsValidUser(clientToken.Username, clientToken.Password)) return false;

            var claim = new[]
            {
                new Claim(ClaimTypes.Name, clientToken.Username)
            };
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_token.Secret));
            var credentials = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var jwtToken = new JwtSecurityToken(
                _token.Issuer,
                _token.Audience,
                claim,
                expires: DateTime.Now.AddMinutes(_token.AccessExpiration),
                signingCredentials: credentials
            );
            token = new JwtSecurityTokenHandler().WriteToken(jwtToken);
            return true;

        }
    }
}
